Liebe Tester,

in der beigef�gten JAR Datei findet ihr unseren aktuellen Entwicklungsstand. 

Es sind bereits folgende Nutzer angelegt:

Benutzername	Passwort	Berechtigungen
admin		123		Administrator
emma		123		Kunde
samuel		123		Kunde

�ber die das Profillogin in der rechten oberen Ecke k�nnt ihr euch einloggen, ansonsten wird der Login normalerweise w�rend des Bestellvorgangs abgefragt. 
Wenn ihr euch als Admin angemeldet habt, findet ihr unter besagtem Icon auf den Link zum Administratordashboard. Dort findet ihr alle Funktionen die 
Mitarbeiter und Admins betreffen. 


Bekannte Bugs/Offene Sachen:
- Suchfunktion ist zur Zeit au�er Funktion
- Bei Ubuntulaptops kann es zu Fehlern bei der Icondarstellung kommen
- Profil Link im Adminbereich ist ohne Funktion
- Beispiel-Artikel-Bilder sind teilweise etwas zu gro� oder zu klein

Viel Spa� damit!

Frohe Weihnachten im nahmen der Gruppe 33 ;)